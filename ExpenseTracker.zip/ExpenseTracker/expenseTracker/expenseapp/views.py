from django.contrib import messages
from django.contrib.auth import get_user_model, authenticate, login
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.http import HttpResponse
from .forms import ExpenseForm
from .models import Expense

# Create your views here.

def signupPage(request):
    if request.method=='POST':
        uname = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirmPassword = request.POST.get('confirm')
        User=get_user_model()

        if password!=confirmPassword:
            return HttpResponse("Password mismatch!, try again")
        else:
            try:
                user = User.objects.create_user(username=uname, email=email, password=password)
                messages.success(request, "Account created successfully. You can now log in.")
                return redirect('login page')
            except Exception as e:
                messages.error(request, "An error occurred. Please try again.")

    return render(request, 'sign-up.html')

def loginPage(request):

    if request.method=='POST':
        username = request.POST.get('username')
        password = request.POST.get('pass')
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('expense page')
        else:
            return HttpResponse("incorrect details!, please try again.")

    return render(request, 'login.html')

def expense(request):
    if request.method == 'POST':
        form = ExpenseForm(request.POST)
        if form.is_valid():
            form.save()  # Save the form data to the database
            return redirect('record page')  # Redirect to the page where you display expense records
    else:
        form = ExpenseForm()

    return render(request, 'expense.html', {'form': form})

def records(request):
    expenses = Expense.objects.all()
    return render(request, 'record.html', {'expenses': expenses})




