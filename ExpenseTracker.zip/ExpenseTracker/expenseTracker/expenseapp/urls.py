from django.urls import path
from . import views

urlpatterns = [
    path('', views.signupPage, name='sign-up page'),
    path('login/', views.loginPage, name='login page'),
    path('expense/', views.expense, name='expense page'),
    path('record/', views.records, name='record page')
]
